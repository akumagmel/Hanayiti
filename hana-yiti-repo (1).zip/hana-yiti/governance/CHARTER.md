# Charter of Organization

(Insert the formal Charter text here.)
