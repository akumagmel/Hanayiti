# Cloudflare Security Baseline (Recommended)

- Enable DNSSEC
- SSL/TLS: Full (strict)
- WAF: On (baseline managed rules)
- Rate limiting: On (protect contact endpoints)
- Bot protection: On
- Always Use HTTPS: On
- HSTS: enable after verification
