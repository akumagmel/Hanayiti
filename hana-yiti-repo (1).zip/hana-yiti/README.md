# HANA Yiti (hanayiti.org)

Institution-grade website + governance repository for the Haitian American Nationals Association (HANA).

## What’s inside
- `governance/` — governance instruments (Charter, Bylaws, policies)
- `public-docs/` — public-facing sanitized documents (mission, governance summary, advocacy framework)
- `site/` — Next.js static-export website for Cloudflare Pages
- `cloudflare/` — Pages + security notes

## Cloudflare Pages (English-first launch)
1. Create a new Cloudflare Pages project and connect this repo.
2. Build settings:
   - **Build command:** `npm run build`
   - **Build output directory:** `out`
3. Attach domain `hanayiti.org` in Cloudflare Pages.

## Security baseline
See `cloudflare/security.md`.
