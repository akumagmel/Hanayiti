# Mission

**The Haitian American Nationals Association advocates for the civic, economic, and human interests of Haitian Americans through disciplined advocacy, policy engagement, and transnational coordination.**
