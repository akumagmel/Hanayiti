# 2026 Advocacy Framework (Public)

## Pillars
1. Advocacy & Representation
2. Civic & Economic Empowerment
3. Identity & National Dignity

## Discipline
- Issue-based advocacy only (non-partisan)
- Formal statements; dated archive
- Coalition alignment standards
