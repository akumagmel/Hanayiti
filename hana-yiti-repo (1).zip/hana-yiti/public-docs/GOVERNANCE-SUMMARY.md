# Governance Summary (Public)

HANA operates under a formal Charter and Bylaws with clear separation between governance, operations, and advisory roles.
Official statements are issued only through authorized channels. The organization maintains non-partisan discipline and
legal oversight to protect credibility and continuity.
